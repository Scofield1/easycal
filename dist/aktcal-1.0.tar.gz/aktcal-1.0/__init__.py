def add_number(num1, num2):
    results = num1 + num2
    return f'Total = {results}'


def subtract_number(num1, num2):
    results = num1 - num2
    return f'Total = {results}'


def multiply_number(num1, num2):
    results = num1 * num2
    return f'Total = {results}'


def exponential_number(num1, num2):
    results = num1 ** num2
    return f'Total = {results}'


def divide_number_float(num1, num2):
    results = num1 / num2
    return f'Total = {results}'


def divide_number_floor(num1, num2):
    results = num1 // num2
    return f'Total = {results}'


def mode_number(num1, num2):
    results = num1 % num2
    return f'Total = {results}'